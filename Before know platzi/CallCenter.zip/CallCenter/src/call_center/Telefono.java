package call_center;

public class Telefono {
    private String numero;

    // Constructor
    public Telefono(String numero) {
        this.numero = numero;
    }

    // Método getNumero para obtener el número del teléfono
    public String getNumero() {
        return this.numero;
    }
}
